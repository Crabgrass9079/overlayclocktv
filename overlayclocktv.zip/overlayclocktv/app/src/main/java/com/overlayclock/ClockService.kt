package com.overlayclock

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class ClockService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var clock: TextView
    private val handler = Handler(Looper.getMainLooper())

    private var driftX = 30
    private var driftY = 30

    private val update = object : Runnable {
        override fun run() {

            val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            clock.text = time

            driftX = 20 + Random().nextInt(40)
            driftY = 20 + Random().nextInt(40)

            val params = clock.layoutParams as WindowManager.LayoutParams
            params.x = driftX
            params.y = driftY
            wm.updateViewLayout(clock, params)

            handler.postDelayed(this, 60000)
        }
    }

    override fun onCreate() {
        super.onCreate()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        clock = TextView(this)
        clock.textSize = 22f
        clock.setTextColor(Color.WHITE)
        clock.setShadowLayer(8f,0f,0f,Color.BLACK)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.END
        params.x = driftX
        params.y = driftY

        wm.addView(clock, params)

        handler.post(update)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}